import React from 'react'
import TimelineCard from '../components/TimelineCard'

const Date = () => {
  return (
    <>
    <TimelineCard/>
    </>
  )
}

export default Date
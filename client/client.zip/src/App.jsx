import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import BackToTopbtn from './components/BackToTopbtn';
import Home from './pages/Home'; // Home page component

import Layout from './components/Layout'; // Layout component with Outlet
import Marquealerts from './components/Marquealerts';
import Footer from './components/Footer';
import GallereyPage from './pages/GallereyPage';
import Blogpage from './pages/Blogpage';
import AmPage from './pages/AmPage';
import ScrollToTop from './common/ScrollTotop';
import Date from './pages/Date';
import AnuCard from './components/AnuCard';
import Anubhav from './pages/Anubhav';
import Bhatti from './pages/Bhatti';



function App() {
  return (
    <Router>
      <ScrollToTop/>
      <Marquealerts/>
      <Navbar />
      <Routes>
        {/* Layout route that wraps nested routes */}
        <Route path="/" element={<Layout />}>
          {/* Define your nested routes */}
          <Route index element={<Home />} /> {/* Home page */}
          <Route path='/gallery/:category' element={<GallereyPage />} />
          <Route path='/Blogs' element={<Blogpage />} />
          <Route path='/Avyakt-murli' element={<AmPage />} />
          <Route path='/schedule' element={<Date />} />
          <Route path='/anubhav' element={<Anubhav />} />
          <Route path='/bhatti' element={<Bhatti />} />

       
        </Route>
      </Routes>
      <Footer/>
      <BackToTopbtn />
    </Router>
  );
}

export default App;

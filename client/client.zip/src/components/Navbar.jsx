import React, { useState } from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="sticky top-0 bg-white shadow-md font-semibold h-24 z-50">
      {/* Header Start */}
      <header className="container mx-auto px-4 py-2 flex items-center justify-between">
        {/* Left-side navigation links */}
        <div className="hidden lg:flex space-x-4"> {/* Reduced space-x from 6 to 4 */}
          <Link to="/schedule" className="text-gray-600 hover:text-gray-900">
            Upcoming Events
          </Link>
          <Link to="/bhatti" className="text-gray-600 hover:text-gray-900">
            Bhatti
          </Link>
        </div>

        {/* Logo in the center */}
        <div className="flex-shrink-0">
          <Link to="/">
            <img
              src="/assets/img/f.png"
              alt="Logo"
              className="h-20 w-auto" // Reduced height of the logo to better fit the navbar
            />
          </Link>
        </div>

        {/* Right-side navigation links */}
        <div className="hidden lg:flex space-x-4"> {/* Reduced space-x from 6 to 4 */}
          <Link to="/Avyakt-murli" className="text-gray-600 hover:text-gray-900">
            Avyakt Murli
          </Link>
          <Link to="/" className="text-gray-600 hover:text-gray-900">
            Online Exam
          </Link>
        </div>

        {/* Mobile menu toggle button */}
        <button
          className="lg:hidden text-gray-600"
          onClick={toggleMenu}
          aria-label="Toggle Menu"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M4 6h16M4 12h16m-7 6h7"
            />
          </svg>
        </button>
      </header>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-gray-900 bg-opacity-50 z-40"
          onClick={toggleMenu}
        ></div>
      )}

      {/* Mobile Menu */}
      <div
        className={`lg:hidden fixed top-0 right-0 h-screen w-3/4 bg-white z-50 transition-transform transform ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* Close Button */}
        <div className="flex justify-end p-4">
          <button
            onClick={toggleMenu}
            aria-label="Close Menu"
            className="text-gray-600 hover:text-gray-900"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        <nav className="flex flex-col space-y-4 p-4 mt-4">
          <Link
            to="/schedule"
            className="block text-gray-700 hover:text-blue-600 text-lg py-2 px-4 rounded-lg transition-colors duration-300 hover:bg-gray-200"
            onClick={toggleMenu}
          >
            Upcoming Events
          </Link>
          <Link
            to="/bhatti"
            className="block text-gray-700 hover:text-blue-600 text-lg py-2 px-4 rounded-lg transition-colors duration-300 hover:bg-gray-200"
            onClick={toggleMenu}
          >
            Bhatti
          </Link>

          <Link
            to="/Avyakt-murli"
            className="block text-gray-700 hover:text-blue-600 text-lg py-2 px-4 rounded-lg transition-colors duration-300 hover:bg-gray-200"
            onClick={toggleMenu}
          >
            Avyakt Murli
          </Link>
          <Link
            to="/online-exam"
            className="block text-gray-700 hover:text-blue-600 text-lg py-2 px-4 rounded-lg transition-colors duration-300 hover:bg-gray-200"
            onClick={toggleMenu}
          >
            Online Exam
          </Link>
        </nav>
      </div>
    </div>
  );
};

export default Navbar;

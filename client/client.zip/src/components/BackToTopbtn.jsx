import React from "react";

const BackToTopbtn = () => {
  return (
    <a href="#" className="scroll-top" id="scroll-top">
      <i className="arrow-top flaticon-up-arrow" />
      <i className="arrow-bottom flaticon-up-arrow" />
    </a>
  );
};

export default BackToTopbtn;

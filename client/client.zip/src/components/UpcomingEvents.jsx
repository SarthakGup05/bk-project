import React from "react";
import { Link } from "react-router-dom"; // Import Link from react-router-dom

const UpcomingEvents = () => {
  return (
    <>
      <div className="upcoming-event-area pb-28">
        <div className="container mx-auto">
          <div className="flex justify-center">
            <div className="text-center">
              <h3 className="section-title center-style text-3xl font-bold">
                Upcoming Events
              </h3>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            {/* Single Activities Start */}
            <div className="single-activities-wrap bg-white rounded-lg shadow-lg">
              <Link to="/schedule" className="activities-imgaes block">
                <img
                  src="\assets\images\activities\2.png"
                  className="w-full h-auto object-cover"
                  alt="Event 1"
                />
              </Link>
              <div className="activities-content text-center p-6">
                <div className="widget-metadata text-sm text-gray-500 mb-2">
                  {/* <Link to="/schedule">
                    
                  </Link> */}
                </div>
                <Link to="/schedule">
                  <h4 className="activities-title text-xl font-semibold mb-2">
                    Date and time
                  </h4>
                </Link>
                {/* <p className="text-gray-600 mb-4">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry.
                </p> */}
                {/* <div className="buy-ticket">
                  <Link to="/schedule" className="text-blue-500 hover:text-blue-700">BUY TICKET</Link>
                </div> */}
              </div>
            </div>
            {/*// Single Activities End */}

            {/* Single Activities Start */}
            <div className="single-activities-wrap bg-white rounded-lg shadow-lg">
              <Link to="/anubhav" className="activities-imgaes block">
                <img
                  src="\assets\images\activities\3.png"
                  className="w-full h-auto object-cover"
                  alt="Event 2"
                />
              </Link>
              <div className="activities-content text-center p-6">
                <div className="widget-metadata text-sm text-gray-500 mb-2">
                  {/* <Link to="/anubhav">
                    <span>Time: 09:30 am to 12:00 pm</span>
                  </Link> */}
                </div>
                <Link to="/anubhav">
                  <h4 className="activities-title text-xl font-semibold mb-2">
                    Anubhav
                  </h4>
                </Link>
                {/* <p className="text-gray-600 mb-4">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry.
                </p> */}
                {/* <div className="buy-ticket">
                  <Link to="/schedule" className="text-blue-500 hover:text-blue-700">FREE</Link>
                </div> */}
              </div>
            </div>
            {/*// Single Activities End */}
          </div>
        </div>
      </div>
      {/* ======== Upcoming Event Area End ========== */}
    </>
  );
};

export default UpcomingEvents;

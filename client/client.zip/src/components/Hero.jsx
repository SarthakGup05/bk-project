import React from "react";
import Slider from "react-slick"; // Import the Slider component
import "slick-carousel/slick/slick.css"; // Import Slick styles
import "slick-carousel/slick/slick-theme.css"; // Import Slick theme styles

const Hero = () => {
  // Slider settings
  const settings = {
    dots: true, // Enable pagination dots
    infinite: true, // Infinite sliding
    speed: 500, // Transition speed
    slidesToShow: 1, // Number of slides to show
    slidesToScroll: 1, // Number of slides to scroll
    autoplay: true, // Enable autoplay
    autoplaySpeed: 3000, // Autoplay speed in milliseconds
  };

  // Dynamic slide data
  const slides = [
    {
      src: "/assets/images/banners/banner1.jpg",
      title: "Buddham namami, dhammam namami sangham namami.",
      buttonText: "Explore more",
    },
    {
      src: "/assets/images/banners/Bnr English.jpg",
      title: "Discover the teachings of Buddha.",
      buttonText: "Learn More",
    },
    // Uncomment for additional slide
    // {
    //   src: "https://picsum.photos/800/400?image=30",
    //   title: "Join us in our journey towards enlightenment.",
    //   buttonText: "Get Started",
    // },
  ];

  return (
    <>
      {/* ======== Hero Area Start ========== */}
      <div className=" overflow-hidden py-0">
        <div className="container mx-auto">
          <Slider {...settings}>
            {slides.map((slide, index) => (
              <div key={index} className="flex justify-end relative">
                <img
                  src={slide.src}
                  alt={slide.title} // Use the title as alt text
                  className="w-full h-auto object-cover" // Ensures the image maintains its aspect ratio and does not crop
                />
              </div>
            ))}
          </Slider>
        </div>
      </div>
      {/* ======== Hero Area End ========== */}
    </>
  );
};

export default Hero;
